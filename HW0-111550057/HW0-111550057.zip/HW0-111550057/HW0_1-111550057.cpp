//
//  HW0_1-111550057.cpp
//  graph theory hw0
//
//  Created by 莊婷馨 on 2023/9/20.
//

#include <iostream>
#include <string>
using namespace std;

int main(){
    string name;
    cin>>name;
    cout<<"Hello "<<name<<"!";
    return 0;
}
